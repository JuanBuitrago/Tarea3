package com.juanbuitrago.solicituddatos;



import android.content.Intent;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.util.Calendar;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    private DatePicker datePicker;
    private Calendar calendar;
    private TextView dateView;
    private int year, month, day;
    TextInputEditText txEdiNombre,txEdiTelefono,txEdiMail,txEdiDescripcion;
    TextView txEdiFecha;
    String stNombre,stTelefono,stEmail,stFecha,stDescripcion;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dateView = (TextView) findViewById(R.id.textView2);
        calendar = Calendar.getInstance();
        year = calendar.get(Calendar.YEAR);

        month = calendar.get(Calendar.MONTH);
        day = calendar.get(Calendar.DAY_OF_MONTH);
        showDate(year, month+1, day);

        //Inicalizar los campos
        incializarEditTexts();
        //Asiganr evento al boton
        Button send = (Button) findViewById(R.id.btnMiBoton);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enviarDatos();
            }
        });

        //Validar si fue llamado con parametros
        Bundle bunConf = getIntent().getExtras();
        //Si recibio parametros
        if( bunConf != null ) {
            stNombre = bunConf.getString(getResources().getString(R.string.DgtNombre));
            stFecha = bunConf.getString(getResources().getString(R.string.Fecha_Elegida));
            stTelefono = bunConf.getString(getResources().getString(R.string.DgtTelefono));
            stEmail = bunConf.getString(getResources().getString(R.string.DgtEmail));
            stDescripcion = bunConf.getString(getResources().getString(R.string.DgtDescripcion));
            //
            incializarEditTexts();
            setDataFromForm();
        }
    }
    public void enviarDatos(){
        //Tomar datos del formulario
        getDataFromForm();
        if( stNombre.length() == 0 || stTelefono .length() == 0 ||
                stEmail.length() == 0 || stFecha.length() == 0 ||
                stDescripcion.length() == 0){
            //Mostrar mensaje por formulario incopleto
            Toast.makeText(getApplicationContext(), "Complete los datos del formulario!", Toast.LENGTH_SHORT).show();
        }else{
            // Crear Objeto Bundle
            Bundle bunParam = new Bundle();
            bunParam.putString(getResources().getString(R.string.DgtNombre),stNombre);
            bunParam.putString(getResources().getString(R.string.Fecha_Elegida),stFecha);
            bunParam.putString(getResources().getString(R.string.DgtTelefono),stTelefono);
            bunParam.putString(getResources().getString(R.string.DgtEmail),stEmail);
            bunParam.putString(getResources().getString(R.string.DgtDescripcion),stDescripcion);
            //instanciar Intent
            Intent intent = new Intent(MainActivity.this,ConfirmarDatos.class);
            //Pasar los parametros al intent
            intent.putExtras(bunParam);
            //iniciar la actividad
            startActivity(intent);
            //Finalizar actividad anterior
            finish();
        }
    }
    public void incializarEditTexts(){
        txEdiNombre   = (TextInputEditText) findViewById(R.id.tienombre);
        txEdiFecha    = (TextView) findViewById(R.id.textView2);
        txEdiTelefono = (TextInputEditText) findViewById(R.id.tietelefono);
        txEdiMail     = (TextInputEditText) findViewById(R.id.tiemail);
        txEdiDescripcion = (TextInputEditText) findViewById(R.id.tiedescripcion);
    }
    public void getDataFromForm(){
        stNombre = txEdiNombre.getText().toString();
        stTelefono = txEdiTelefono.getText().toString();
        stEmail = txEdiMail.getText().toString();
        stFecha = txEdiFecha.getText().toString();
        stDescripcion = txEdiDescripcion.getText().toString();
    }

    public void setDataFromForm(){
        txEdiNombre.setText(stNombre);
        txEdiTelefono.setText(stTelefono);
        txEdiMail.setText(stEmail);
        txEdiFecha.setText(stFecha);
        txEdiDescripcion.setText(stDescripcion);
    }
    @SuppressWarnings("deprecation")
    public void setDate(View view) {
        showDialog(999);
        Toast.makeText(getApplicationContext(), "Seleccione fecha", Toast.LENGTH_SHORT)
                .show();
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        // TODO Auto-generated method stub
        if (id == 999) {
            return new DatePickerDialog(this, myDateListener, year, month, day);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener myDateListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker arg0, int arg1, int arg2, int arg3) {
            // TODO Auto-generated method stub
            // arg1 = year
            // arg2 = month
            // arg3 = day
            showDate(arg1, arg2+1, arg3);
        }
    };

    private void showDate(int year, int month, int day) {
        dateView.setText(new StringBuilder().append(day).append("/")
                .append(month).append("/").append(year));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //   getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
};