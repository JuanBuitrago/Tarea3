package com.juanbuitrago.solicituddatos;

/**
 * Created by JuanBuitrago on 29/07/2017.
 */
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.widget.TextView;

public class ConfirmarDatos extends AppCompatActivity {

    private TextView txEdiNombre;
    private TextView txEdiFecha;
    private TextView txEdiTelefono;
    private TextView txEdiEmail;
    private TextView txEdiDescripcion;
    String stNombre,stTelefono,stEmail,stFecha,stDescripcion;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.confirmardatos);

        //Recuperar parametros
        Bundle parametros = getIntent().getExtras();
        //
        String nombre  = parametros.getString(getResources().getString(R.string.DgtNombre));
        String fecha   = parametros.getString(getResources().getString(R.string.Fecha_Elegida));
        String telefono= parametros.getString(getResources().getString(R.string.DgtTelefono));
        String email   = parametros.getString(getResources().getString(R.string.DgtEmail));
        String descripcion   = parametros.getString(getResources().getString(R.string.DgtDescripcion));
        //Tomar referencia de los objetos
        txEdiNombre       = (TextView) findViewById(R.id.tieNombre);
        txEdiFecha        = (TextView) findViewById(R.id.tieFecha);
        txEdiTelefono     = (TextView) findViewById(R.id.tieTelefono);
        txEdiEmail        = (TextView) findViewById(R.id.tieEmail);
        txEdiDescripcion  = (TextView) findViewById(R.id.tieDescripcion);
        //Asignar valores
        txEdiNombre.setText(nombre);
        txEdiFecha.setText(fecha);
        txEdiTelefono.setText(telefono);
        txEdiEmail.setText(email);
        txEdiDescripcion.setText(descripcion);
        //
        Button send = (Button) findViewById(R.id.btnEditar);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editarDatos();
            }
        });
    }

    public void editarDatos(){
        // Crear Objeto Bundle
        Bundle bunParam = new Bundle();
        bunParam.putString(getResources().getString(R.string.DgtNombre),txEdiNombre.getText().toString());
        bunParam.putString(getResources().getString(R.string.Fecha_Elegida),txEdiFecha.getText().toString());
        bunParam.putString(getResources().getString(R.string.DgtTelefono),txEdiTelefono.getText().toString());
        bunParam.putString(getResources().getString(R.string.DgtEmail),txEdiEmail.getText().toString());
        bunParam.putString(getResources().getString(R.string.DgtDescripcion),txEdiDescripcion.getText().toString());
        //instanciar Intent
        Intent intent = new Intent( ConfirmarDatos.this, MainActivity.class);
        //Pasar los parametros al intent
        intent.putExtras(bunParam);
        //iniciar la actividad
        startActivity(intent);
        //Finalizar actividad anterior
        finish();
    }

}
